<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>无标题文档</title>
</head>

<body>
<?php
        include("conn.php");
        $username=$_COOKIE['username'];
        $password=$_POST['password'];
		$password2=$_POST['password2'];
		$telephone=$_POST['telephone'];
		$gender=$_POST['gender'];
		$age=$_POST['age'];
		$qq=$_POST['qq'];
		$email=$_POST['email'];
     
		if((empty($username))||(empty($password))||(empty($password2))||(empty($telephone))||(empty($gender))||(empty($age))||(empty($qq))||(empty($email))){
		    echo "<script>alert('有信息为空，修改失败！');location.href='customer_update.php'</script>";
		}
		elseif ($password!=$password2){
		    echo "<script>alert('两次密码不一致，请重新确认密码！');location.href='customer_update.php'</script>";
		}
		else{
            $sql="UPDATE customer SET cus_tel='$telephone', cus_gender='$gender',cus_age='$age',cus_qq='$qq',cus_email='$email',cus_pwd='$password' where cus_name='$username'";
            if (!mysql_query($sql)){
                die('Error:'.mysql_error()); 
            }else{
                mysql_close();
                echo "<script>alert('修改成功！');location.href='customer_info.php'</script>";
            }
		}
        
  ?>
</body>
</html>