﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8 />
	<title>点餐了么</title>
    <meta name="keywords",content=""/>
    <link href="../css/style1.css"  rel="stylesheet" type="text/css" />
	<style>
	.shouye{
	 margin:0 auto;
	 width:1024px;;         
	 height:650px;     /*主页面的长宽必须设置，否则出现放大页面变乱的情况*/
}
	.shop_content{
		margin-top:250px;
	}
	.shop_content div{
		margin-bottom:90px;
		height:240px;
	}
	.shop_content div a{
		text-decoration:none;
		color:#336699;
	}
	.shop_content div a:hover{
		text-decoration:none;
		color:#339999;
	}
	.shop_content ul li{
		list-style:none;
		width:250px;
		height:200px;
		border:6px solid #FFFF99;
		float:left;
		margin:20px;
		background:#FFCC33;
		margin-top:80px;
		margin-bottom:100px;
 }
	.shop_content ul li a{
		text-decoration:none;
		color:black;
		padding-left:50px;
	}
	.shop_content ul li a:hover{
		text-decoration:none;
		color:#336699;
		padding-left:50px;
	}
	.shop_content ul li span{
		color:#336699;
		padding-left:15px;
		margin-top:10px;
	}
	*{               /*通配，去掉默认的值，否则出现意外的bug*/
	padding:0; 
	margin:0; 
} 
/*用户中心*/
.user_center{
	
	padding-left:70px;
	height:40px;
	background:#F3F3F3;
	line-height:28px;
	padding-right:80px;
	border:1px solid #C0C0C0;
	
}
.login{
 
	text-decoration:none;	
	font-size:12px;
	color:#000000;
}
.login a:hover{
	text-decoration:none;
}
.register{
	
	text-decoration:none;
	font-size:12px;	
	color:#6D6D6D;
}
.user_center a:hover{
	text-decoration:none;	
	font-size:12px;
	color:#FF6633;
}
.user_center ul{
padding-top:5px;
	list-style:none;
}
.user_center ul a:hover{
	text-decoration:none;
}
.user_center ul li{
 
	float:right; 
	font-size:12px;
	line-height:30px;
	text-align:center; 
    position:relative;
	
	/*border:1px solid red;*/
}
.user_center ul li a{
	text-decoration:none; 
	color:#6D6D6D;
    display:block;
	margin-right:10px;
	width:80px;
	
}
.user_center ul li a:hover{
	text-decoration:none; 
	color:#FF7F00;
	

}
.user_center ul li ul{
	margin-left:10px;
	position:fixed;
    display:none;  /*默认none*/
	
}
.user_center ul li ul li{
	float:none; 
	line-height:30px;
	text-align:center;
	font-size:12px;
	
}
.user_center ul li ul li a{
	 display:table-row;
	 text-align:center;
	 
}
/* 触发li中的ul标签*/
.user_center ul li:hover ul{    /* 可添加触发之后的列表的相关特性*/
	margin-top:3px;
	display:block;
	border:1px solid #C0C0C0;
	background:#FFFFFF;
}

/*logo和搜索框*/
.banner{
	width:960px;
	height:200px;
	float:left;	
	position:relative;
	padding-right:80px;
}
.banner_log{ 
     
	padding-top:10px;
	 
	float:left;
}
.banner_log img{      /*banner_log的子元素选择器*/
	height:20% ;
	width:150px;
}
.banner_title img{
	height:50% ;
	width:250px;
	padding-left:20px;
	padding-top:40px;
	float:left;    /*设置浮动很有必要*/
}
.banner_search{
	padding-top:10px;
	
	width:560px;
	float:right;
	
}

.search_word{
	font-size:6px;
	margin-left:160px;
	
	padding-top:15px;	
}
.search_word a{
	text-decoration:none;	
	color:#6D6D6D;
	padding-right:20px;
}
.search_word a:hover{
	color:#FF7F00;
	text-decoration:underline;
}
.banner_search_border{
	padding-left:20px;
	width:55%;
	height:34px;
	margin-left:160px;
	margin-top:50px;
	border:2px solid #FF7F00;
	outline:0;  /*去掉文本域默认的蓝色边框*/
}
.banner_search_button{
	width:50px;
	height:38px;
	border:2px solid #FF7F00;
	color:#FFF;
	background:#FF7F00;
	margin-left:-8px;
	padding-bottom:1px; /*使用上边的挪不下来，就试试下边的呗*/
	outline:0; 
	
}

.banner_small_log{
	margin-top:55px;
	padding-right:100px;
	height:200px;
	float:right;	
}

/*目录内容*/

.catalogue{
	width:1024px;
	float:left;
	height:40px;
	background:#F3F3F3;
	position:relative;
	 
	border:1px solid #C0C0C0;
}
.catalogue_detail{
	padding-top:15px;
	font-size:16px ;
	font-weight:bold;	

}
.catalogue_detail a{
	margin-left:75px;
	padding-top:15px;
	text-decoration:none;	
	color:black;
}
.catalogue_detail a:hover{
	color:#CCCCFF;
}
.shop{
	
}
.update_course{
	width:150px;
	float:left;
	margin-top:13px;
	margin-left:40px;
	 
	height:320px;	     /*一旦此处高度太低，下一个div会与下边的东西重合*/
	position:relative;
	 
	padding-top:4px;
	
	
}
.update_course ul{
	list-style:none;
}

.update_course ul hr{
	width:250px;
	margin-top:3px;
	padding-top:1px;
}
.update_course ul a{
	text-decoration:none;
	 color:#000066;
	 font-size:15px;
}
.update_course ul li{

	font-size:15px;
	padding-top:10px;

}

 

.hot_programming{
	width:150px;
	float:left;
	margin-top:13px;
	margin-left:150px;
	padding-left:20px;
	height:320px;
	 
	position:relative;
	padding-right:80px;
	 	  
	padding-top:4px;
	
}
.hot_programming ul a{
	text-decoration:none;
	 color:#000066;
	 font-size:15px;
}
.hot_programming ul hr{
	margin-top:3px;
	width:250px;
	color:#3366CC;
	padding-top:1px;
	
}
.hot_programming ul {
	list-style:none;
}

.hot_programming ul li{

	font-size:15px;
	padding-top:10px;

}
 

.update_comment{
	width:150px;
	float:left;
	margin-top:13px;
	margin-left:100px;
	 
	height:320px;
	position:relative;
	padding-right:80px;
	 	  
	padding-top:4px;
	
}
.update_comment ul a{
	text-decoration:none;
	 color:#000066;
	 font-size:15px;
}
.update_comment ul hr{
	width:250px;
	margin-top:3px;
	padding-top:1px;
}
.update_comment ul {
	list-style:none;
}
.update_comment ul li{

	font-size:15px;
	padding-top:10px;

}


.foot{
	width:1024px;
	height:60px;
	float:left;
	background:#F3F3F3;
	
	border:1px solid #C0C0C0;
	
}

.foot p{
	text-align:center;
	font-size:11px;
	padding-top:4px;
	color:black;
}
.foot p a{
	text-decoration:none;
	color:black;
}
li{list-style:none;}
.a{background:#FFCC33;border:6px solid #FFFF99;width:200px;height:220px;float:left;margin:20px;}
.b {
	font-family: MS Serif, New York, serif;
	color:#FF9900;
	font-size: 20px;
}
.c {
	font-family: MS Serif, New York, serif;
	color: #FF9900;
	font-size: 30px;
	font-weight:bold;
}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#D9DEE8; height: 25px; width: 150px; 
            text-align: center; border: #D9DEE8; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			}

	</style>
</head>
 <body>
	<div class="shouye">
			<div class="user_center">
        	<ul> 
            	<a href="" class="login" ><?php echo "欢迎您,".$_COOKIE['username']?></a>&nbsp;
                <a href="customer_register.php" class="register" >快速注册</a> 
                <li><a href="customer_info.php">个人中心</a>
                	<ul>
                    	<li><a href="customer_cart.php">我的购物车</a></li>
						<li><a href="customer_order.php">我的订单</a></li>
                        <li><a href="customer_update.php">修改个人信息</a></li>
                    </ul>
                </li>
            </ul>
        </div>

		<!--logo和搜索框-->
        <div calss="banner">
        	<div class="banner_log"><a href=""><img src="../images/log.jpg"  /></a></div>
			<div class="banner_title"><a href=""><img src="../images/title.png"/></a></div>
            <div class="banner_search">    
            	<input type="text" class="banner_search_border" placeholder="全站搜索" />
                <a href=""><input type="button"  class="banner_search_button" value="搜索" /></a>
                <p class="search_word" > <a href="">重庆小面</a>&nbsp;&nbsp;<a href="">烤肉饭</a>&nbsp;&nbsp;
                <a href="">鸡公煲</a>&nbsp;&nbsp;
                <a href="">麻辣烫</a>&nbsp;&nbsp;<a href="">火锅</a>&nbsp;&nbsp;<a href="">黄焖鸡</a>&nbsp;&nbsp;
                 
            </div>   
        </div>
		
		<!--catalogue-->
		<div class="catalogue">
		
		</div>

		<!--首页的内容-->
		<div class="shop_content">
			<ul>
<?php
include("conn.php");
if(!empty($_GET['id'])){
$id=$_GET["id"];
//输出餐馆信息
$sql="select * from shop where id=$id";
$result=mysql_query($sql);
$msg=mysql_fetch_array($result);
	echo "<span class='c'>{$msg['shopname']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	echo "<span class='b'>地址:{$msg['address']}</span>&nbsp;&nbsp;";
	echo "<span class='b'>餐馆负责人:{$msg['owner']}</span>&nbsp;&nbsp;";
	echo "<span class='b'>联系电话:{$msg['telnum']}</span>&nbsp;&nbsp;";}
	
//输出菜品信息
$sql2="select * from food where shopid=$id";
$result2=mysql_query($sql2);
while($msg2=mysql_fetch_array($result2)){
	echo "<div class='a'>";
    echo "<img src='../images/".$msg2['image']."' height='150' width='200'/>";
	echo "<span>菜品名：{$msg2['foodname']}</span>&nbsp;&nbsp;<br>";
	echo "<span>价格:{$msg2['price']}</span> <br>";
	echo "详细介绍:{$msg2['introduce']}<br>";
	if(!empty($_COOKIE['username'])){
	echo "<a href=customer_cart.php?id={$msg2['foodid']}>加入购物车</a>";
	}
	echo "</div>";
}
?>

			</ul>
		</div>



		<!--copyright-->
		<div class=foot>
			<p style="margin-top:10px;"><a href="" >版权所有@2021 武汉纺织大学2018级计算机科学与技术孙嘉鸣</a>
		</div>
	</div>
 </body>
</html>
