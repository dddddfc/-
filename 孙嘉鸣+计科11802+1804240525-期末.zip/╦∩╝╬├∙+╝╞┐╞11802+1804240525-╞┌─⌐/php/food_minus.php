<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>购物车数量减一</title>
</head>
<?php
include("conn.php");
$username=$_COOKIE['username'];
//购物车对应商品减一
//if(!empty($_GET['id']))
{
	$carid=$_GET["id"];
	//判断数量，如果只有一个就直接删除掉，如果不止一个再进行更新
	$sql="select * from shopcar where carid='$carid'";
	$result=mysql_query($sql);
	$msg=mysql_fetch_array($result);
	if($msg['quantity']==1)
		mysql_query("delete from shopcar where carid='$carid'");
	else	
		mysql_query("UPDATE `shopcar` SET `price`=perprice*(quantity-1),`quantity`=quantity-1 WHERE carid='$carid'");
}
    Header("Location:customer_cart.php");
?>
<body>
</body>
</html>