<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>用户个人中心</title>
</head>
<style>
li{ list-style:none;background:#FFCC99;border:solid #FFCC99; width:500px}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#FFCC99; height: 25px; width: 150px; 
            text-align: center; border: #FFCC99; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			}
</style>
<body>
<?php
include("conn.php");
?>
<center>
<h2 style='color:#FFCC99'>个人信息</h2>
<p><a href=customer_show.php class='btn'>返回首页</a></p>
<?php
if(!empty($_COOKIE['username'])){
	$username=$_COOKIE['username'];
	$sql="select * from customer where cus_name='$username'";
	$result=mysql_query($sql);
	$msg=mysql_fetch_array($result);
	echo "<br />";
	echo "<br />";
	
	echo "<li><br />";
	echo "<span>用户名：{$msg['cus_name']}</span>&nbsp;&nbsp;<br>";
	echo "<span>手机号:{$msg['cus_tel']}</span>&nbsp;&nbsp;<br>";
	echo "<span>性别:{$msg['cus_gender']}</span>&nbsp;&nbsp;<br>";
	echo "<span>年龄:{$msg['cus_age']}</span>&nbsp;&nbsp;<br>";
	echo "<span>QQ:{$msg['cus_qq']}</span>&nbsp;&nbsp;<br>";
	echo "<span>email:{$msg['cus_email']}</span>&nbsp;&nbsp;</li>";
	echo "<br /><br><a href=customer_update.php class='btn'>修改个人信息</a></br>";
}
?>
</center>
</body>
</html>