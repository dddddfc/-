<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>购物车数量加一</title>
</head>
<?php
include("conn.php");
$username=$_COOKIE['username'];
//购物车对应商品加一
//if(!empty($_GET['id']))
{
	$carid=$_GET["id"];	
	$sql="UPDATE `shopcar` SET `price`=perprice*(quantity+1),`quantity`=quantity+1 WHERE carid='$carid'";
	mysql_query($sql);
}
    Header("Location:customer_cart.php");
?>
<body>
</body>
</html>