<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>用户注册页面</title>
<style>
	#form1{
		width:500px;
		height:450px;
		border:1px solid;
		background:#FFCC99;
	}
	#form1 p{
		text-align:center;
	}
	#form1 a{
		text-decoration:none;
	}
</style>
</head>
<?php
include("conn.php");
if(!empty($_POST['button'])){
    $username=$_POST['username'];
	$password=$_POST['password'];
	$password2=$_POST['password2'];
	$telephone=$_POST['telephone'];
	$gender=$_POST['gender'];
	$age=$_POST['age'];
	$qq=$_POST['qq'];
	$email=$_POST['email'];
	$sql2="select * from customer where cus_name='$username'";
	$result=mysql_query($sql2);
	
	if($password!=$password2){
	   echo"两次密码不一致，请重新确认注册密码！";
	}
	else if(mysql_num_rows($result)>0){
		echo"该用户已存在！请重起用户名！";
	}
	else{
		$sql="INSERT INTO `customer` (`id`, `cus_tel`, `cus_name`, `cus_gender`, `cus_age`, `cus_qq`, `cus_email`, `cus_pwd`) VALUES (null,'$telephone','$username','$gender','$age','$qq','$email','$password')";
		mysql_query($sql);
		$time=time()+3600;
		setcookie("username",$username,$time);
	    setcookie("islogin",true);
	    echo "<script>alert('注册成功！');location.href='customer_show.php'</script>";
	}
}
?>
<body>
<center>
<form id="form1" name="form1" method="post" action="">
  <p>姓名：
    <label for="username"></label>
    <input type="text" name="username" id="username" />
  </p>
   <p>手机号：
    <label for="telephone"></label>
    <input type="text" name="telephone" id="telephone" />
  </p>
    <p>性别：
    <label for="gender"></label>
    <input type="text" name="gender" id="gender" />
  </p>
    <p>年龄：
    <label for="age"></label>
    <input type="text" name="age" id="age" />
  </p>
    <p>QQ：
    <label for="qq"></label>
    <input type="text" name="qq" id="qq" />
  </p>
    <p>Email：
    <label for="email"></label>
    <input type="text" name="email" id="email" />
  </p>
  <p>密码：
    <label for="password"></label>
    <input type="text" name="password" id="password" />
  </p>
  <p>确认密码：
    <label for="password2"></label>
    <input type="text" name="password2" id="password2" />
  </p>

  <p>&nbsp;</p>
  <p>
    <input type="submit" name="button" id="button" value="注册" />
  </p>
  <p><a href="customer_login.php">已有账号？一键登录</a></p>
</form>
<center>
</body>
</html>