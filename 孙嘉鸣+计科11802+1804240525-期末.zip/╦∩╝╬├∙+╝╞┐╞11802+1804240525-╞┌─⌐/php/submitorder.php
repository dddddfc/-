<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>提交订单</title>
</head>
<?php
//接收cookie username和对应的商家id
include("conn.php");
$username=$_COOKIE['username'];
$shopid=$_GET['id'];
//通过对应的username和商家id，将订单信息汇总到一个contents变量里
$sql="select * from shopcar where username='$username' and shopid='$shopid'";
$result=mysql_query($sql);
$sql2="select * from shop where id='$shopid'";
$result2=mysql_query($sql2);
$msg2=mysql_fetch_array($result2);
$contents1="";
$allprice=0;
while($msg=mysql_fetch_array($result)){
	$contents1=$contents1."<br><span>菜品名：{$msg['foodname']}</span>&nbsp;&nbsp;"."<span>数量:{$msg['quantity']}</span>&nbsp;&nbsp;"."<span>金额:{$msg['price']}</span>&nbsp;&nbsp;";
	$allprice=$allprice+$msg['price'];
	$shopname=$msg['shopname'];
}
$contents1="<br />商家名：{$msg2['shopname']}".$contents1."<br />总金额：￥".$allprice;

//确认提交按钮，点击改按钮可以内容写入订单表中，并删除原有购物车中相关信息
$sql3="INSERT INTO `myorder` (`orderid`, `username`, `shopid`, `time`, `contents`) VALUES (null,'$username','$shopid',now(),'$contents1')";
mysql_query($sql3);
mysql_query("delete from shopcar where username='$username' and shopid='$shopid'");
echo "<script>alert('提交成功，请耐心等待配送');location.href='customer_show.php'</script>";
?>

<body>
</body>
</html>