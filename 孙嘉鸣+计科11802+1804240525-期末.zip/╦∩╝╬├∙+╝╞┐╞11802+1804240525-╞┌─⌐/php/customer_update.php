<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>无标题文档</title>
</head>
<style>
li{
list-style:none;
background:#FFCC99;
border:solid #FFCC99;
margin-bottom:10px;
padding-top:80px;

}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#FFCC99; height: 25px; width: 150px; 
            text-align: center; border: #FFCC99; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			}
</style>
<style>
	#form1{
		width:500px;
		height:450px;
		border:1px solid;
		background:#FFCC99;
	}
	#form1 p{
		text-align:center;
	}
	#form1 a{
		text-decoration:none;
	}
</style>
<script>
 
</script>
<body><center>
<?php
include("conn.php")

?>

<?php
if(!empty($_COOKIE['username'])){
    @$username=$_COOKIE['username'];
	@$password=$_POST['password'];
	@$password2=$_POST['password2'];
	@$telephone=$_POST['telephone'];
	@$gender=$_POST['gender'];
	@$age=$_POST['age'];
	@$qq=$_POST['qq'];
	@$email=$_POST['email'];
$sql="SELECT * FROM customer WHERE cus_name='$username'";
$result=mysql_query($sql);
$msg=mysql_fetch_array($result);

?>
<h2 style='color:#FFCC99'>您正在修改个人信息</h2>
<p><a href=customer_show.php class='btn'>返回首页</a></p>
<form  id='form1' name='form1' method="post" action='customer_update_save.php'>
    	
        账户名：<?php echo $msg['cus_name'] ?>
    
    <input type="hidden" name="username" id="username" value="<?php echo $msg['cus_name'];?>" /><br />
       <p>手机号：
    <label for="telephone"></label>
    <input type="text" name="telephone" id="telephone" />
  </p>
    <p>性别：
    <label for="gender"></label>
    <input type="text" name="gender" id="gender" />
  </p>
    <p>年龄：
    <label for="age"></label>
    <input type="text" name="age" id="age" />
  </p>
    <p>QQ：
    <label for="qq"></label>
    <input type="text" name="qq" id="qq" />
  </p>
    <p>Email：
    <label for="email"></label>
    <input type="text" name="email" id="email" />
  </p>
  <p>密码：
    <label for="password"></label>
    <input type="text" name="password" id="password" />
  </p>
  <p>确认密码：
    <label for="password2"></label>
    <input type="text" name="password2" id="password2" />
  </p>
    <input type="submit" name="button" id="button" value="提交" />
</form>
<?php }


?>
</center></body>
</html>