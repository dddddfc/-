<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>查看产生订单</title>
</head>
<style type="text/css">
.c{background:#FFCC33;border:solid #FFCC33; width:500px; margin-top:100px;}
li{list-style:none;}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#FFCC33; height: 25px; width: 150px; 
            text-align: center; border: #FFCC33; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			color:#000000;
			}
.big{
	width:600px;
	height:400px;
	border:1px solid #FFCC33;
}
</style>
<body>
<center>
<?php
//接收cookie username和对应的商家id
include("conn.php");
echo "<h2 style='color:#FFCC33'>订单详情</h2>";
echo "<p ><a href=customer_show.php class='btn'>返回首页</a></p>";
$username=$_COOKIE['username'];
$shopid=$_GET['id'];
//通过对应的username和商家id，将订单信息汇总到一个contents变量里
$sql="select * from shopcar where username='$username' and shopid='$shopid'";
$result=mysql_query($sql);
$contents1="";
$allprice=0;
while($msg=mysql_fetch_array($result)){
	$contents1=$contents1."<br><span>菜品名：{$msg['foodname']}</span>&nbsp;&nbsp;"."<span>数量:{$msg['quantity']}</span>&nbsp;&nbsp;"."<span>金额:{$msg['price']}</span>&nbsp;&nbsp;";
	$allprice=$allprice+$msg['price'];
	$shopname=$msg['shopname'];
	
}
//显示订单信息
echo "<div class='big'>";
echo "<div class='c'>";
	echo "<li>店铺名：{$shopname}</span>&nbsp;&nbsp;";
	echo "<li>订单内容:{$contents1}</span>&nbsp;&nbsp;";
	echo "<li>总金额:{$allprice}元&nbsp;&nbsp;";
	echo "</div>";
//确认提交按钮，点击改按钮可以内容写入订单表中
echo "<br><a href=submitorder.php?id={$shopid} class='btn'>提交订单</a>&nbsp;&nbsp;<a href=customer_cart.php?id={$shopid} class='btn'>返回购物车</a>&nbsp;&nbsp;";
echo "</div>";
?>
</center>
</body>
</html>