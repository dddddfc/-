<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>购物车</title>
</head>
<style>
li{
	list-style:none;
	background:#FFCC33;
	border:solid #FFCC33;
	margin-bottom:10px;
	margin-top:30px;
	width:760px;

}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#FFCC33; height: 25px; width: 150px; 
            text-align: center; border: #D9DEE8; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			}
div{
	width:860px;
	height:500px;
	border:1px solid #FFCC66;
}
</style>
<body>
<center>
<?php 
error_reporting(E_ERROR); 
//ini_set("display_errors","Off"); //屏蔽警告信
include("conn.php");
$username=$_COOKIE['username'];
echo "<h2 style='color:#FF9900'>"."我的购物车</h2>";
echo "<p><a href=customer_show.php class='btn'>返回首页</a></p>";

//用户添加商品进入购物车
//if(!empty($_GET['id']))
{
	$foodid=$_GET["id"];//获取传递过来的菜品为唯一id
	//先获取传递过来的商品对应的商店id、价格、商品名、商店名
	$sql0="select * from food where foodid='$foodid'";
	$result0=mysql_query($sql0);
	$msg0=mysql_fetch_array($result0);
	$shopid=$msg0['shopid'];
	$perprice=$msg0['price'];
	$foodname=$msg0['foodname'];
	//获取商店名
	$sql1="select * from shop where id='$shopid'";
	$result1=mysql_query($sql1);
	$msg1=mysql_fetch_array($result1);
	$shopname=$msg1["shopname"];
	//插入数据
	$sql4="INSERT INTO `shopcar` (`carid`, `username`, `foodid`, `shopid`, `foodname`, `perprice`, `price`, `quantity`, `shopname`) VALUES (null,'$username','$foodid','$shopid','$foodname','$perprice','$perprice',1,'$shopname')";
	mysql_query($sql4);
}
//用户查看购物车
$sql6="select * from shopcar where username='$username'";
$result6=mysql_query($sql6);
echo "<div>";
while($msg6=mysql_fetch_array($result6)){
	
	echo "<li>";
	echo "<span>菜品名：{$msg6['foodname']}</span>&nbsp;&nbsp;";
	echo "<span>店铺名:{$msg6['shopname']}</span>&nbsp;&nbsp;";
	echo "<span>数量:<a href=food_minus.php?id={$msg6['carid']}>[-1] </a>{$msg6['quantity']}</span>";
	echo "<span><a href=food_plus.php?id={$msg6['carid']}> [+1]</a>&nbsp;&nbsp;";
	echo "<span>金额:{$msg6['price']}</span>&nbsp;&nbsp;";
	echo "<span><a href=food_delete.php?id={$msg6['carid']}>删除</a>&nbsp;&nbsp;";
	echo "<span><a href=order_caculate.php?id={$msg6['shopid']}>核算订单</a>&nbsp;&nbsp;";
	echo "<span><a href=food_show.php?id={$msg6['shopid']}>进入该店铺</a>&nbsp;&nbsp;";
	echo "</li>";}
echo "</div>";
?>
</center></body>
</html>