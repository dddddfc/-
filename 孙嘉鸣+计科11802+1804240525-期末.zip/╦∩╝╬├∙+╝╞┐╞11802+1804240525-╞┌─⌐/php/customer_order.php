<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>查看订单</title>
</head>
<style type="text/css">
.c{background:#FFCC33;border:solid #FFCC33; width:500px;margin:20px}
li{list-style:none;border:solid #FFCC33;}
.btn{	padding-right:2px; 
            padding-left: 2px; 
            padding-bottom: 2px; 
            padding-top: 2px; 
            background-color:#FFCC33; height: 25px; width: 150px; 
            text-align: center; border: #FFCC33; border-style: outset; 
            border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; 
            border-left-width: 2px;
			text-decoration:none;
			color:black;
			}
</style>
<body>
<center>
<?php
include("conn.php");?>
<h2 style='color:#FFCC33'>您的历史订单</h2>
<p ><a href=customer_show.php class="btn">返回首页</a></p>
<?php
$username=$_COOKIE['username'];
$sql="select * from `myorder` where username='$username'";//注意order是数据库自己的关键字 所以一定要有反引号！！！！！
$result=mysql_query($sql);
$count=0;
while($msg=mysql_fetch_array($result))
{
	$count=$count+1;
	echo  "<div class='c'>";
	echo "<li>订单号:{$count}</li>";
	echo "<li>详细内容:{$msg['contents']}</li>";
	echo "</div>";
}
?>
</center>
</body>
</html>