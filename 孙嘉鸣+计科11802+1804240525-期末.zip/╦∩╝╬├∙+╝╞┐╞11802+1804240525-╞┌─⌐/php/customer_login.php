<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>用户登录页面</title>
</head>
<script type="text/javascript" src="../js/login.js" charset="utf-8">
</script>
<?php
error_reporting(E_ERROR); 
ini_set("display_errors","Off"); //屏蔽警告信息
include("conn.php");
if(!empty($_POST['button'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$sql="select * from customer where cus_name='$username' and cus_pwd='$password'";
	//echo "$sql";
	$result=mysql_query($sql);
	if(mysql_num_rows($result)>0){
	$time=time()+3600;
	setcookie("username",$username,$time);
	setcookie("islogin",true);
	echo "<script>alert('登陆成功');location.href='customer_show.php'</script>";
	}
	else
	echo "<script>alert('用户名或密码错误，请重新登陆')</script>";
}
?>
<body>
<center>
  <br><br><br><br><br>
  <table width="684" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="292" align="center" valign="top" background="../Images/LoginBg.jpg">
      <table width="350" height="201" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="72" align="center"><h3>用户登陆界面</h3></td>
        </tr>
        <tr>
          <td align="center" valign="top">
             <form name="form1"  method="post" onSubmit="return mycheck()">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  
                  </tr>
                <tr>
                  <td width="37%" height="30" align="right" style="padding-top:20px;">用户名：</td>
                  <td width="300" align="left" ><input type="text" name="username" id="username" style="margin-top:20px;"/></td>
                  </tr>
                <tr>
                  <td height="30" align="right" class="STYLE2">密码：</td>
                  <td align="left"><input type="password" name="password" id="password" class="text1" /></td>
                  </tr>
                <tr>
                  <td height="30" colspan="2" align="center"><label>
                    <input type="submit" name="button" id="button" value="登录">
                  </label></td>
                  </tr>
              </table>
              </form>
          
          </td>
        </tr>
      </table></td>
    </tr>
  </table>


</center>
</body>
</html>