<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>无标题文档</title>
</head>

<body>
<?php
    include("conn.php");
    $username=$_COOKIE['username'];
    echo $username."您好!这是您的购物车";
    if(!empty($_GET['id'])){
        $carid=$_GET["id"];
        //删除购物车对应carid的记录
        $sql="DELETE FROM `shopcar` WHERE carid='$carid' ";
        mysql_query($sql);
        Header("Location:customer_cart.php");
    }
?>
</body>
</html>